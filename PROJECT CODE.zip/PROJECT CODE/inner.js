function disp() {  

            var strText = document.getElementById("tx1").value;          
            var strText1 = document.getElementById("tx2").value;
			var strText2 = document.getElementById("tx3").value;
			var strText3 = document.getElementById("tx4").value;
		    num1 = document.getElementById("tx5").value;
			
			var e=document.getElementById("tps");
			var value=e.value;
			var strText5=e.options[e.selectedIndex].text;
			
			
		    num2 = document.getElementById("tx6").value;
			
			
		    r1 = document.getElementById("r1");
		    r2 = document.getElementById("r2");
			num3 = ((num1 * value)-(num1 / num2 ));
			num5 = 720;
	        num6 = 360;
			num4 = num3/2;
		    num7 = num4+num6;
			num8 = num3+num5;

    document.write("<center><table border='5px' rules='all' cellpadding='5px' width: '200px'>");
	document.write("<tr bgcolor='linen'>");
    document.write("<td><img src= pic1.png height='75' width='75'></td>");
    document.write("<td><h3><center>PROPERTY TAX PAYMENT</center></h3></td>");
	document.write("<td><h3><center><a href=home.html text-decoration= 'none'>HOME</a></center></h3></td>");
	document.write("<td><h3><center><a href=about.html>ABOUT</a></center></h3></td>");
	document.write("<td><h3><center><a href=example.html>CALCULATION</a></center></h3></td>");
	document.write("<td><h3><center><a href=gateway.html>PAYMENT</a></center></h3></td>");
    document.write("</tr>");	
	document.write("</table>");	
	document.write("<strong>ENTERED DETAILS :-</strong>" +"<br>");
			
    
    document.write("<table border='10px' rules='all' cellpadding='10px'>");
	document.write("<tr>");
            document.write("<td>NAME:</td>");
            document.write("<td>" +strText +"</td>");		
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>PHONE NO:</td>");
       		document.write("<td>" +strText1 +"</td>");	
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>HOUSE NO:</td>");
            document.write("<td>" +strText2 +"</td>");			
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>AREA:</td>");
            document.write("<td>" +strText3 +"</td>");			
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>SQAURE FEETS:</td>");
            document.write("<td>" +num1 +"</td>");			
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>USAGE:</td>");
            document.write("<td>" +strText5 +"</td>");			
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>PLAN:</td>");
			if(r1.checked==true)
            document.write("<td>" +r1.value +"</td>");
            if(r2.checked==true)
            document.write("<td>" +r2.value +"</td>");				
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>GARBAGE TAX:</td>");
			if(r1.checked==true)
            document.write("<td>" +num6 +"</td>");
            if(r2.checked==true)
            document.write("<td>" +num5 +"</td>");				
	document.write("</tr>");
	document.write("<tr>");
            document.write("<td>AMOUNT:</td>");
			if(r1.checked==true)
            document.write("<td>" +num7 +"</td>");	
		    if(r2.checked==true)
            document.write("<td>" +num8 +"</td>");				
	document.write("</tr>");
	document.write("</table></center>");
	
	
			
} 